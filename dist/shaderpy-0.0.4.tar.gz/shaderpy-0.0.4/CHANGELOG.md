## Change Log
============

0.0.1 (2021-02-27)
-------------------
- First Release

0.0.2 (2021-02-27)
-------------------
- Added error handling when compiling shaders and linking programs.

0.0.3 (2021-02-27)
-------------------
- Fixed description.

0.0.4 (2021-02-27)
-------------------
- Actually fixed description.